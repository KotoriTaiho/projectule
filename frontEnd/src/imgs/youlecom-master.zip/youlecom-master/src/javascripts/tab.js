var li_eles = document.querySelectorAll(".li-list li");
        var content_eles = document.querySelectorAll(".box");
        var cate_bd = document.querySelector(".cate-bd")
        // 2. 绑定事件 : 
        for(let  i = 0 ; i < li_eles.length ; i ++){
              li_eles[i].onmouseover = function(){
                    reset() 
                    li_eles[i].className = "active";
                    content_eles[i].className += " active";
              }
        }
        for(let  i = 0 ; i < li_eles.length ; i ++){
            content_eles[i].onmouseout = function(){
                    reset() 
                    li_eles[i].className = "";
                    content_eles[i].className += " box";
              }
        }
        
        function reset(){
              for(var i = 0 ; i < li_eles.length ; i ++){
                    li_eles[i].className = "";
                    content_eles[i].className = "box";
              }
        }