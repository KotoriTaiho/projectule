window.onload = function () {};

var mySwiper1  = new Swiper( ".my-container", {
      // 添加按钮切换事件
      navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
      },   
      // 自动播放 
      autoplay : true,
      // 支持无限滚动
      loop : true,
      // 分页器配置
      pagination : {
            el : ".swiper-pagination",
            clickable  : true,
      }

} )

for(var i = 0 ; i < mySwiper1.pagination.bullets .length ; i ++){
      mySwiper1.pagination.bullets[i].onmouseover = function(){
            this.click();
      }
}


var mySwiper1  = new Swiper( ".jd-container", {
      // 添加按钮切换事件
      // navigation: {
      //       nextEl: '.swiper-button-next',
      //       prevEl: '.swiper-button-prev',
      // },   
      // 自动播放 
      autoplay : true,
      // 支持无限滚动
      loop : true,
      // 分页器配置
      pagination : {
            el : ".swiper-pagination",
            clickable  : true,
      },
      // effect : "fade"
      effect : "cube"
} )



